//to Qianyi: the code is built base on W4 exercise and her demonstration on W5 live lecture first 20 minutes
//progress: most of basic + intermediate

//as I didnot write serve side, the below "event-sensor" is for my testing purpose, they might be not required if serve side exist

//global variable to help me store values
let columnsChoice = ''
let columnsNames = []
let boardCode = ''
// load
function loadData(code, key){
	fetch('http://localhost:11288/boards/' + code+'?key='+key, {
		method: 'GET',
		headers: {
			'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
		}
	}).then(res => res.json())
		.then(res => {
			if(res.rescode) {
				alert(res.msg)
			} else{
				data = {
					code: res.code,
					title: res.title
				}
				columnsChoice = res.columnsChoice;
				columnsNames = res.columnsNames;
				boardCode = code;
				displayBoards(data);
				if(!res.cards) res.cards=[];
				for(let i = 0 ; i <res.cards.length ;i++){
					createCardsToFirstStage(res.cards[i]);
				}
			}
			console.log(res);
			
		}).catch(error => {
			console.log(error);
			
		});
}
document.getElementById('load_board_button').addEventListener('click', function () {
	const code = document.getElementById('code').value;
	if(!code.trim()) {
		alert('board code not null!');
	}
	const key = prompt('Please enter the secret key for board '+code);
	loadData(code, key);
});
//hint: ctrl+f the 'id' in indel.html of P2client.js may help you understand the code
document.getElementById('add_card_button').addEventListener('click', function () {
	let cardTitle = document.getElementById("card-title").value;
	let cardDescription = document.getElementById("card-description").value;
	let cardSubTask = document.getElementsByClassName("subtaskItems");
	let subtask = {}
	if(!columnsNames || ! columnsNames[0]) {
		alert('please add column');
		return ;
	}
	for (i = 0; i < cardSubTask.length; i++) {
		subtask[cardSubTask[i].textContent] = false;
	}
	let data = {
		"cardTitle": cardTitle,
		"cardDescription": cardDescription,
		"cardSubTask": subtask,
		"column" : columnsNames[0]
	}
	// console.log(data)
	let isCreated = document.getElementById(data.cardTitle)
	if(!data.cardTitle){
		alert("card title not null!");
	}else if (!isCreated) { 
		fetch('http://localhost:11288/card/add?code='+boardCode, {
			method: 'POST',
			body: JSON.stringify(data),
			headers: {
				'content-type': 'application/json',
				'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
			}
		}).then(res => res.json())
			.then(res => {
				console.log(res);
				
				createCardsToFirstStage(res) 
				document.getElementById("card-title").value = ''
				document.getElementById("card-description").value = ''
				document.getElementById("subtask-list").innerHTML = ''
			}).catch(error => {
				console.log(error);
			});
		
	} else { alert("You have created such cards!") }
	
})

document.getElementById("option_to_add_board").onclick = function () {
	document.getElementById("to_add_board").style.display = "initial"
	document.getElementById("option_to_add_board").style.display = "none"
	document.getElementById("load_board_button").style.display = "none"
	
}

document.getElementById('add_board_button').addEventListener('click', function () {
	let code = document.getElementById("code").value;
	let title = document.getElementById("title").value;
	let data = {
		"code":code,
		"title": title
	}
	let radioChoice = document.getElementsByName('columnsOption')
	for (let radio of radioChoice) {
		if (radio.checked) {
			data.columnsChoice = radio.value
		}
	}
	console.log(data.columnsChoice)

	if (data.columnsChoice == 'defaultColumns') {
		data.columnsNames = ['waiting', 'in-progress', 'completed']
	} else { console.log("not default") }
	fetch('http://localhost:11288/boards/add', {
		method: 'POST',
		body: JSON.stringify(data),
		headers: {
			'content-type': 'application/json',
			'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
		}
	}).then(res => res.json())
		.then(res => {
			console.log(res);
			if(res.rescode) {
				alert(res.msg);
				return;
			}
			alert('The secret key for ' + res.code + ' is ' + res.key + '\n Please make a note of your key so you can access the board later!');
			data = {
				code: res.code,
				title: res.title
			}
			boardCode = res.code;
			columnsChoice = res.columnsChoice;
			columnsNames = res.columnsNames?res.columnsNames:[];
			document.getElementById("to_add_board").style.display = "none"
			document.getElementById("option_to_add_board").style.display = "initial"
			document.getElementById("load_board_button").style.display = "initial"
			document.getElementById('code').value = ''
			document.getElementById('title').value = ''
			displayBoards(data);
		}).catch(error => {
			console.log(error);
		});

	// let randomstring = Math.random().toString(36).slice(-6); //create a key 
	// alert(`The secret key for ${code} is ${randomstring}. Please make a note of your key so you can access the board later!`)


})

document.getElementById('add_column_button').onclick = function () {
	let columnName = document.getElementById('column-name').value
	let columnPosition = document.getElementById('column-position').value
	let isCreated = columnsNames.indexOf(columnName.trim()) == -1;
	if(!columnName.trim()) {
		alert('column name not null！');
	}else if(isCreated){
		addColumn(columnName, columnPosition);
	}else{
		alert('You have created such column!');
	}
	
}

document.getElementById('create_subtask_button').onclick = function () {
	let subtaskList = document.getElementById('subtask-list')
	let listItem = document.createElement('li')
	listItem.setAttribute('class', "subtaskItems")
	listItem.innerText = document.getElementById('subtask-to-add').value
	if(!listItem.innerText.trim()){
		alert('Subtask not null');
		return;
	}
	subtaskList.appendChild(listItem)
}
//to Qianyi: the code for the load button on the 'Boards'(most upper part of the website) should be at serve side?

//for below comments, they are possible useful to merge with serve side later:(not useful for my client side testing)
// //handler for the add button - calls the addBoards API
// function addBoards() {
// 	let code = document.getElementById("code").value;
// 	let title = document.getElementById("title").value;
// 	let data = { title: title };

// 	fetch(`/modules/${code}`, {
// 		method: 'POST',
// 		headers: { 'Content-Type': 'application/json' },
// 		body: JSON.stringify(data) 
// 	})
// 	.then (res => res.text())
// 	.then (txt => alert(txt))
// 	.then ( getBoards );
// }

// // handles call to getBoards API
// async function getBoards() {
// 	return fetch(`/boards/codes`)
// 	.then (res => res.json())
// 	.then (jsn => displayBoards(jsn)) 
// }

//displays the board of the module 
function displayBoards(json) {
	document.getElementById("board").style.display = "initial" //reveal the 'display=none' section in html
	document.getElementById("board_title").innerHTML = json.code + "-" + json.title;
	createBoards()
}

function createBoards() {
	let boardDetails = document.getElementById('board_details')
	boardDetails.innerHTML = ''
	if(!columnsNames) columnsNames = [];
	for (i = 0; i < columnsNames.length; i++) {

		let column = document.createElement('section')
		column.setAttribute('id', 'column' + i)
		
		column.setAttribute('class', 'stage')

		let columnTitle = document.createElement('h2')
		columnTitle.setAttribute('class', 'stage-name')
		columnTitle.innerText = columnsNames[i]

		let columnDetails = document.createElement('p')
		// columnDetails.setAttribute('id', 'columnDisplay' + i)
		// columnDetails.setAttribute('id', columnsNames[i])
		columnDetails.setAttribute('index', i)
		columnDetails.setAttribute('class', 'cards_details ' + columnsNames[i]);

		column.appendChild(columnTitle)
		column.appendChild(columnDetails)
		boardDetails.appendChild(column)
	}

	document.getElementById('column-position').setAttribute('max', columnsNames.length)
}

function addColumn(name, position) {
	if(!columnsNames) columnsNames = [];
	var columnsNames2 = [...columnsNames];
	console.log(columnsNames2)
	columnsNames2.splice(position, 0, name)
	console.log(columnsNames2)
	fetch('http://localhost:11288/column/add?code='+boardCode, {
		method: 'POST',
		body: JSON.stringify(columnsNames2),
		headers: {
			'content-type': 'application/json',
			'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
		}
	}).then(res => res.json())
		.then(res => {
			document.getElementById('column-name').value = '';
			document.getElementById('column-position').value = '';
			loadData(boardCode);
			// columnsNames = res;
			// createBoards()
		}).catch(error => {
			console.log(error);
		});
	
}

//displays the module details 
function createCardsToFirstStage(json) {
	let firstStage = document.getElementsByClassName(json.column)[0];
	if(firstStage) {
		let div = createCards(json)
		firstStage.appendChild(div);
	}
	
}
function createCards(json) {
	//create the card details
	let div = document.createElement("div");
	div.setAttribute("class", "card");
	div.setAttribute("id", json.cardTitle);

	//input the title
	let title = document.createElement("h3")
	title.innerText = json.cardTitle
	//input description
	let paragraph = document.createElement("p")
	paragraph.innerHTML = json.cardDescription
	//input subtask
	let form = document.createElement("form")
	for (let i in json.cardSubTask) {
		let input = document.createElement('input')
		input.setAttribute('type', 'checkbox')
		input.setAttribute('id', '#' + i)
		input.setAttribute('name', i)
		console.log(json.cardSubTask[i],typeof json.cardSubTask[i])
		// input.setAttribute('checked', json.cardSubTask[i])
		input.checked = json.cardSubTask[i]
		input.onchange = function(e){changeTask(json,e)}
		let label = document.createElement('label')
		label.setAttribute('for', '#' + i)
		label.innerText = i

		let nextLine = document.createElement('br')

		form.appendChild(input)
		form.appendChild(label)
		form.appendChild(nextLine)
	};

	//create the move button inside the card
	let moveButton = document.createElement("button")
	moveButton.setAttribute("class", "move_button");
	// moveButton.setAttribute("id", "move_to_in_progress_button");
	moveButton.onclick = function () { moveToNextStage(json) }
	moveButton.innerHTML = "move"
	//create the delete button inside the card
	let deleteButton = document.createElement("button")
	deleteButton.setAttribute("class", "delete_button");
	deleteButton.onclick = function () { deleteCards(json.cardTitle) }
	deleteButton.innerHTML = "delete"
	//create the save button inside the card
	let saveButton = document.createElement("button")
	saveButton.setAttribute("class", "save_button");
	saveButton.onclick = function () { saveCards(json.cardTitle) } //To Qianyi: saveCards function not yet write
	saveButton.innerHTML = "save"

	//append buttons in card and append card
	div.appendChild(title)
	div.appendChild(paragraph)
	div.appendChild(form)
	div.appendChild(moveButton);
	div.appendChild(deleteButton);

	return div

}
// allow sub-tasks to be marked as complete
function changeTask(json,e, index) {
	json.cardSubTask[e.target.name] = e.target.checked;
	console.log(json,999,json.cardTitle,e.target.value,e.target.name)
	fetch('http://localhost:11288/task/complete?code=' + boardCode+'&task='+e.target.name+'&value='+e.target.checked + '&title='+json.cardTitle, {
		method: 'GET',
		headers: {
			'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
		}
	}).then(res => res.json())
		.then(res => {
			loadData(boardCode);
		}).catch(error => {
			console.log(error);
		});
}
function deleteCards(id) {
	console.log(id, boardCode);
	if (confirm("Are you sure you want to delete this card? Once confirmed this action cannot be undone.")) {
		// document.getElementById(id).remove()
		fetch('http://localhost:11288/card/delete?code=' + boardCode+'&id='+id, {
		method: 'GET',
		headers: {
			'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
		}
	}).then(res => res.json())
		.then(res => {
			loadData(boardCode);
		}).catch(error => {
			console.log(error);
		});
		
	}
}

function moveToNextStage(json) {
	console.log('columnsNames.length' + columnsNames.length)
	// let oldstage = (document.getElementById(json.cardTitle).parentElement.id)
	let oldstage = (document.getElementById(json.cardTitle).parentElement.getAttribute('index'))

	// let newStage = Number(oldstage[oldstage.length - 1]) + 1
	let newStage = Number(oldstage) + 1
	console.log(newStage, columnsNames);
	if (columnsNames.length > newStage) {

		//delete the original card
		fetch('http://localhost:11288/card/move?code='+boardCode, {
			method: 'POST',
			body: JSON.stringify({
				title: json.cardTitle,
				column: columnsNames[newStage]
			}),
			headers: {
				'content-type': 'application/json',
				'Authorization': 'Basic YWRtaW46c3VwZXJzZWNyZXQ='
			}
		}).then(res => res.json())
		.then(res => {
			loadData(boardCode);
			// console.log(res);
			
			// document.getElementById(json.cardTitle).remove()
			// let nextStage = document.getElementById("columnDisplay" + newStage);
			// let div = createCards(json)
			// nextStage.appendChild(div);
		}).catch(error => {
			console.log(error);
		});
		
	} else {
		alert("This is the final stage, you cannot move anymore.")
	}
}

//Outstanding: 
//1. load function
//2. save fucntion
//3. all cards would disspear if a column us added (would it be possible for the server side store the all cards? then i can update all card's id and create them into the new columns)
//4. control when a card/board should be accepted (all question must be answered?)
//5. aesthetic design (final step)
