const express = require('express');
const expressBasicAuth = require('express-basic-auth');
const bodyParser = require('body-parser');
const { nanoid } =  require('nanoid');
const app = express();
const API_PORT = 11288; //if running on school servers use you unique id found by running "id -u"

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true })) //optional but useful for url encoded data

//Collection of valid users - key value pairs of username : password
// - in a real app we would not hard code these or store them in plain text!!!
const users = {
    'admin': 'supersecret',
    'adam': 'password1234',
    'eve': 'qwackers'
}

//register the valid username, password pairs with the express-basic-auth object
const authorise = expressBasicAuth({
    users: users,
	unauthorizedResponse: (req) => ((req.auth)? 'Credentials  rejected' : 'No credentials provided'),
	challenge: true	//make the browser ask for credentials if none/wrong are provided
})

const boards = { 
	CS5003: { title: "Masters Programming Projects",code: "CS5003", columnsChoice: "noColumns", key: "ABCDEF"},
};


//get all the module codes
app.get('/boards/codes', function(req,res,next) {
	res.status(200).json(Object.keys(boards)); 
});

//get the details of a specific module
app.get('/boards/:CODE', function(req,res,next) {
	const code = req.params.CODE;
	const key  = req.query.key
	
	if ( boards[code]) { 
		if(!key || key=='undefined'  || (key == boards[code].key)) {
			res.status(200).json(boards[code]); 
		}else {
			res.status(400).json({
				rescode: 1,
				msg: "error secret key for boardsecret key for board " + code
			}); 
		}
		
	}
	else { 
		res.status(400).send({
			rescode: 2,
			msg: "No such boards"
		}); 
	}
});

//add a new module
app.post('/boards/add', authorise, function(req,res,next) {
	if(!boards[req.body.code]) {
		req.body.key = nanoid(6);
		boards[req.body.code ] = req.body;
		console.log(req.body,99)
		res.status(200).json(req.body);
	}else {
		res.status(400).json({
			rescode: 1,
			msg: "You have created such board! "
		}); 
	}
	
});


//add a new column
app.post('/column/add', authorise, function(req,res,next) {
	let code = req.query.code;
	boards[code].columnsNames = req.body;
	res.status(200).json(req.body);
});

//add a new card
app.post('/card/add', authorise, function(req,res,next) {
	let code = req.query.code;
	if(!boards[code].cards) boards[code].cards = [];
	boards[code].cards.push(req.body);
	res.status(200).json(req.body);
});
//move card
app.post('/card/move', authorise, function(req,res,next) {
	let code = req.query.code;
	console.log(req.body.column,req.body.title, code)
	if(!boards[code].cards) boards[code].cards = [];
	for(let i = 0 ; i< boards[code].cards.length ; i++){
		console.log(boards[code].cards[i].cardTitle ,req.body.title);
		if(boards[code].cards[i].cardTitle == req.body.title) {
			boards[code].cards[i].column = req.body.column;
		}
	}
	res.status(200).json({
		msg: 'move success'
	});
});
app.get('/card/delete', authorise,function(req, res, next){
	let code = req.query.code;
	console.log(req.query.id, code)
	if(!boards[code].cards) boards[code].cards = [];
	for(let i = 0 ; i< boards[code].cards.length ; i++){
		if(boards[code].cards[i].cardTitle == req.query.id) {
			boards[code].cards.splice(i, 1);
		}
	}
	res.status(200).json({
		msg: 'delete success'
	});
});
app.get('/task/complete', authorise,function(req, res, next){
	let code = req.query.code;
	let task = req.query.task;
	let title = req.query.title;
	let val = req.query.value == 'true';
	for(let i = 0 ; i< boards[code].cards.length ; i++){
		if(boards[code].cards[i].cardTitle == title) {
			boards[code].cards[i].cardSubTask[task] = val;
		}
	}
	
	res.status(200).json({
		msg: 'task change success'
	});
});
app.use(express.static('content'));

// tell the server to listen on the given port and log a message to the console (so we can see our server is doing something!)
app.listen(API_PORT, () => {
	console.log(`Listening on localhost:${API_PORT}`)
});
